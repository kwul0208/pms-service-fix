

<?php $__env->startSection('content'); ?>
 <div class="container">
     <h4>Sprint</h4>
<div>
   <a href="<?php echo e(url('sprint/create')); ?>"> <button class="btn btn-success">Create New</button></a>
</div>


<?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a href="<?php echo e(url('sprint/sprinttask/'.$sprint->sprint_id.'/'.$sprint->date)); ?>"><button class="btn btn-default btn-sm"><?php echo e($sprint->date); ?></button></a>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Title Sprint</th>
            <th scope="col">Period</th>
            <th scope="col">Goal</th>
            <th scope="col">Action</th>
          </tr>
          </tr>
        </thead>
        <tbody>
          
          <?php $__currentLoopData = $sprints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sprint): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
         
          <tr>
            <th scope="row">1</th>
            <td> <?php echo e($sprint->title); ?> </td>
            <td><?php echo e($sprint->date); ?>  </td>
            <td><?php echo e($sprint->description); ?></td>
            <td>
              <a href="<?php echo e(url('sprint/'.$sprint->id)); ?>">
                <button class="btn btn-default btn-sm">Detail</button>
              </a>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      
        </tbody>
      </table>
 </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Sprint\Resources/views/show.blade.php ENDPATH**/ ?>