<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/prism.css">
<link rel="stylesheet" href="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/chosen.css">

  <!-- Main Content -->
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-12 col-md-12 mx-auto">
        <div class="post-preview">
          <a href="post.html">
           
            <h3 class="post-subtitle">
                Task Index
            </h3>
          </a>
          <p class="post-meta">Posted by
            <a href="#">Start Bootstrap</a>
            on September 24, 2019</p>
        </div>

        
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">

              <li class="nav-item  ">
                <a class="nav-link" href="<?php echo e(url('task/index/all#heading')); ?>">All</span></a>
              </li>
              <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
              
              <li class="nav-item  
              <?php 

              if( Request::segment(4) == $key){ 
                ?>
active
                <?php 
              } ?>
              ">
                <a class="nav-link" href="<?php echo e(url('task/index/'.$status.'/'.$key)); ?>"><?php echo e($employee); ?></span></a>
              </li>
           
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            </ul>
            
          </div>
        </nav>
        <br>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  

          <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
              <li class="nav-item 
              <?php if($status =='not_started'){ ?>
              active
              <?php } ?>
              ">
                <a class="nav-link" href="<?php echo e(url('task/index/not_started/'.Request::segment(4) .'#heading')); ?>">Not Started</span></a>
              </li>
              <li class="nav-item
              <?php if($status =='ongoing'){ ?>
                active
                <?php } ?>
              ">
                <a class="nav-link" href="<?php echo e(url('task/index/ongoing/'.Request::segment(4).'#heading')); ?>">Ongoing</a>
              </li>
              <li class="nav-item
              <?php if($status =='done'){ ?>
                active
                <?php } ?>
              ">
                <a class="nav-link" href="<?php echo e(url('task/index/done/'.Request::segment(4) .'#heading')); ?>">Done</a>
              </li>
            
            </ul>
            <form class="form-inline my-2 my-lg-0">
              <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
              <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
            </form>
          </div>
        </nav>
<br>
     
        <div class="pull-right">
            <a href="<?php echo e(url('task/create')); ?>" >
                <button type="button" class="btn btn-success btn-add-task">Create New</button>
            </a>
        </div>

        <table class="table" id="table-add-task">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Project</th>
              <th scope="col">Status</th>
              <th scope="col">Assigned to</th>
              <th scope="col">Action</th>
            </tr>
          </thead>
          <tbody>
              <form action="<?php echo e(url('task/store')); ?>" method="POST">
                  <?php echo csrf_field(); ?>
              <tr>
                  <th scope="col">#</th>
                  <th scope="col">
                    <input type="text" name="name"  class="form-control" placeholder="Title"/>
                    <br />
                  <textarea name="description"  class="form-control" placeholder="Description" ></textarea>
                  </th>
                  <th scope="col"> <select name="project_id" data-placeholder="Choose a Project..." class="chosen-select" tabindex="2"> 
                      <option></option>
                  <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($project->id); ?>"><?php echo e($project->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                  </select></th>
                  <th scope="col">                
                      <select name="status" class="form-control">
                        <option selected  value="not_started">Not Started</option>
                        <option  name="status">Ongoing</option>
                        <option  value="done">Done</option>
                      </select>
  
                      <br>
                      <label>Start Date</label>
                      <input type="date" name="start_date" >
                      <br>
                      <label>Due Date</label>
                      <input type="date" name="due_date" >
                  </br>
  
                      
  
                        
                  </th>
                  <th scope="col">
                    <select required name="employees_id[]" data-placeholder="Choose a team member..." class="chosen-select" multiple tabindex="4">
                      <option value=""></option>
                     <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees_id => $employees_fullname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <option value="<?php echo e($employees_id); ?>"><?php echo e($employees_fullname); ?></option>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
  
                    <br>
                      <br>
                      
                      <select name="category" data-placeholder="Category" class="chosen-select">
                        <option value=""></option>
                        <option value="new_feature">New Feature</option>
                        <option value="improve_feature">Improve Feature</option>
                        <option value="fixing_bug_error">Fixing Bug Error</option>
                        <option value="other">Other</option>
                      </select>
                      
                  </th>
                  <th scope="col"><input type="submit" value="Add"  class="btn btn-success form-control"></th>
                </tr>
  
                <input type="hidden" name="redirect" value="<?php echo e(url()->current()); ?>">
              </form>
          </tbody>
        </table>

    <table class="table">
        <thead>
          <tr>
            <th scope="col">#</th>
            <th scope="col">Name</th>
            <th scope="col">Project</th>
            <th scope="col">Status</th>
            <th scope="col">Assigned to</th>
            <th scope="col">Timespent</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          
          <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              
         
          <tr>
            <th scope="row"><?php echo e($key + 1); ?>.</th>
            <td><?php echo e($task->task_name); ?>

              <?php if($task->description): ?>
              <br>
             <i> <?php echo e($task->description); ?></i>
              <?php endif; ?>
            </td>
            <td>
                <?php if($task->project_id): ?>
                    <?php echo e($task->project->name); ?>

                <?php endif; ?>
            </td>
            <td style="text-transform:capitalize"><?php echo e(preg_replace( array('/_/'), array(' '), $task->status)); ?>

                
<!--
                    <?php if($task->status=='ongoing'): ?>
                    <br>
                        Start : <?php echo e($task->working_start_date); ?>

                    <?php endif; ?>

                    <?php if($task->status=='done'): ?>
                    <br>
                        Start : <?php echo e($task->working_start_date); ?>

                        <br>
                        
                        Finish : <?php echo e($task->working_finish_date); ?>

                    <?php endif; ?>
-->
            </td>
            
            <td>
              
            <?php $__currentLoopData = $task->assignedTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedTo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($assignedTo->employees->fullname); ?> <br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          
            </td>
            <td>
              <?php $__currentLoopData = $task->assignedTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedTo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e(substr($assignedTo->employees->fullname,0,1)); ?> : <?php echo e($task->timespentPerTeam($task->id, $assignedTo->employees->id)); ?>

               <br>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

           Total   <?php echo e($task->timespent($task->id)); ?>

            </td>
            <td><a href="<?php echo e(url('task/'.$task->id)); ?>"><Button class="btn btn-danger">Detail</Button></a></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
    </div>
  </div>
</div>

<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/chosen.jquery.js" type="text/javascript"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/prism.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/init.js" type="text/javascript" charset="utf-8"></script>

<script>

    
  $('#table-add-task').hide();
  // btn add task
  $('.btn-add-task').click(function(e){
    e.preventDefault();
    
    $('#table-add-task').show();
  })

  $('.btn-cancel').click(function(e){
    e.preventDefault();
    
    $('#table-add-task').hide();
  })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Task\Resources/views/index.blade.php ENDPATH**/ ?>