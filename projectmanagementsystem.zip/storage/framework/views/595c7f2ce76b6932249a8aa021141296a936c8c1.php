 <!-- <link href="<?php echo e(url('assets/Rapid')); ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="<?php echo e(url('assets/Rapid')); ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet">
 --> 
<h1>Timesheet</h1>

<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Date</th>
            <th>Timestart</th>
            <th>Timefinish</th>
            <th>Project</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <?php $key=1; ?>
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
        <tr>
            <td><?php echo e($key++); ?>.</td>
            <td><?php echo e($timesheet->date); ?></td>
            <td><?php echo e($timesheet->timestart); ?></td>
            <td><?php echo e($timesheet->timefinish); ?></td>
            <td><?php echo e(@$timesheet->project->title); ?></td>
            <td><?php echo nl2br($timesheet->description); ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Timesheet\Resources/views/browse.blade.php ENDPATH**/ ?>