

<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="<?php echo e(url('assets/calendar/jquery-ui.css')); ?>">


  <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 mx-auto">

        <div class="post-preview">
          <a href="<?php echo e(url('project')); ?>">
           
            <h3 class="post-subtitle">
              Timesheet Team
            </h3>
          </a>
        </div>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
  

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
              <ul class="navbar-nav mr-auto">
  
                
                <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=> $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  
                
                <li class="nav-item  
                <?php 
  
                if( Request::segment(4) == $key){ 
                  ?>
  active
                  <?php 
                } ?>
                ">
                  <a class="nav-link" href="<?php echo e(url('team/timesheet/index/'.$key.'/'.date('Y-m-d'))); ?>"><?php echo e($employee); ?></span></a>
                </li>
             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
              </ul>
              
            </div>
          </nav>
          <br>
               

<br>
<div align="center">
<div id="datepicker"></div>
<div>Date : <span id="date"></span></div>
</div>
<div id="timesheet">
<h1>Timesheet</h1>


<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Date</th>
            <th>Timestart</th>
            <th>Timefinish</th>
            <th>Project</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <?php $key=1; ?>
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
        <tr>
            <td><?php echo e($key++); ?>.</td>
            <td><?php echo e($timesheet->date); ?></td>
            <td><?php echo e(@$timesheet->timestart); ?></td>
            <td><?php echo e(@$timesheet->timefinish); ?></td>
            <td><?php echo e(@$timesheet->project->title); ?></td>
            <td><?php echo @$timesheet->description; ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>  
  
  </div>
</div>

    <?php echo $__env->yieldContent('script'); ?>
   

    <script src="<?php echo e(url('assets/calendar/jquery-1.12.4.js')); ?>"></script>
<script src="<?php echo e(url('assets/calendar/jquery-ui.js')); ?>"></script>
<script>
$( function() {

    var employees_id = '<?php echo e(Request::segment(4)); ?>';
    $("#datepicker").datepicker({
        dateFormat: "yy-mm-dd",
      
        onSelect: function (date) {
            var url = '<?php echo e(url("timesheet/browse")); ?>/'+employees_id+'/'+date;
            $('#date').text(date);
            // alert(url);
            $('#timesheet').load(url);
        }
    });
} );
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Team\Resources/views/timesheet_team/index.blade.php ENDPATH**/ ?>