<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
<link rel="stylesheet" href="https://jqueryui.com/resources/demos/style.css">




  <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 mx-auto">

        <div class="post-preview">
          <a href="<?php echo e(url('project')); ?>">
           
            <h3 class="post-subtitle">
              Timesheet
            </h3>
          </a>
        </div>

               

<br>
<div align="center">
<div id="datepicker"></div>
<div>Date : <span id="date"></span></div>
</div>
<div id="timesheet">
<h1>Timesheet</h1>


<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Date</th>
            <th>Timestart</th>
            <th>Timefinish</th>
            <th>Project</th>
            <th>Description</th>
        </tr>
    </thead>
    <tbody>
        <?php $key=1; ?>
        <?php $__currentLoopData = $timesheets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $timesheet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
        
        <tr>
            <td><?php echo e($key++); ?>.</td>
            <td><?php echo e($timesheet->date); ?></td>
            <td><?php echo e($timesheet->timestart); ?></td>
            <td><?php echo e($timesheet->timefinish); ?></td>
            <td><?php echo e(@$timesheet->project->title); ?></td>
            <td><?php echo $timesheet->description; ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>  
  
  </div>
</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Timesheet\Resources/views/index.blade.php ENDPATH**/ ?>