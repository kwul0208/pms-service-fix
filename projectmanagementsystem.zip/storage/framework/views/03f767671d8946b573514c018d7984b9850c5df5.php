<?php $__env->startSection('content'); ?>


<link rel="stylesheet" href="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/chosen.css">

  <!-- Main Content -->
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 mx-auto">

        <div class="post-preview">
          <a href="<?php echo e(url('project')); ?>">
           
            <h3 class="post-subtitle">
                <?php echo e($project->name); ?>

            </h3>
          </a>
        </div>

               
<nav class="navbar navbar-expand-lg navbar-light bg-light">
  

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item 

      ">
        <a class="nav-link" href="<?php echo e(url('project/'.$project->id)); ?>">Detail</span></a>
      </li>
      <li class="nav-item
  
      ">
        <a class="nav-link" href="<?php echo e(url('project/task/'.$project->id)); ?>">Task</a>
      </li>
   <!--   <li class="nav-item  ">
        <a class="nav-link" href="<?php echo e(url('project/team/'.$project->id)); ?>">Team</a>
      </li> -->
      <li class="nav-item
   
      ">
        <a class="nav-link" href="<?php echo e(url('project/meeting/'.$project->id)); ?>">Meeting</a>
      </li> 
    
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
      <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
    </form>
  </div>
</nav>
        <table class="table">
          <thead>
            <tr>
              <th scope="col">#</th>
              <th scope="col">Name</th>
              <th scope="col">Status</th>
              <th scope="col">Assigned to</th>
              <th scope="col">Action</th>
            </tr>
           
            </thead>
            <tbody>
                <form action="<?php echo e(url('project/taskProject/store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">
                    <textarea name="name"  class="form-control" ></textarea>
                    <br>
                    <br>
                    
                    <select name="category" data-placeholder="Category" >
                      <option value=""></option>
                      <option value="new_feature">New Feature</option>
                      <option value="improve_feature">Improve Feature</option>
                      <option value="fixing_bug_error">Fixing Bug Error</option>
                      <option value="other">Other</option>
                    </select>
                    </th>
                   
                    <th scope="col">                
                        <select name="status" class="form-control">
                          <option selected  value="not_started">Not Started</option>
                          <option  name="status">Ongoing</option>
                          <option  value="done">Done</option>
                        </select>
                        <br>
                          <label>Start Date</label>
                          <input type="date" name="start_date" >
                          <br>
                          <label>Due Date</label>
                          <input type="date" name="due_date" >
                      </br>
                          
                    </th>
                    <th scope="col">
                      <select required name="employees_id[]" data-placeholder="Choose a team member..." class="chosen-select" multiple tabindex="4">
                        <option value=""></option>
                       <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employees_id => $employees_fullname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <option value="<?php echo e($employees_id); ?>"><?php echo e($employees_fullname); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>

                    


                    </th>
                    <th scope="col"><input type="submit" value="Add"  class="btn btn-success form-control"></th>
                  </tr>
                  <input type="hidden" name="project_id" value="<?php echo e($project_id); ?>">
                </form>
          </thead>
          <tbody>
        <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
          
        <tr>
          <th scope="row"><?php echo e($key + 1); ?>.</th>
          <td><?php echo e($task->task_name); ?></td>
          <td><?php echo e($task->status); ?></td>
          <td>

            <?php $__currentLoopData = $task->assignedTo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignedTo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($assignedTo->employees->fullname); ?> <br>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </td>
          <td><a href="<?php echo e(url('project/'.$task->id)); ?>"><Button class="btn btn-danger">Detail</Button></a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>

      </table>
    </div>
    </div>
  </div>
</div>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/jquery-3.2.1.min.js" type="text/javascript"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/chosen.jquery.js" type="text/javascript"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/prism.js" type="text/javascript" charset="utf-8"></script>
<script src="<?php echo e(url('assets/chosen_v1.8.7/')); ?>/docsupport/init.js" type="text/javascript" charset="utf-8"></script>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Project\Resources/views/task_project/index.blade.php ENDPATH**/ ?>