
<?php $__env->startSection('content'); ?>

  <!-- Main Content -->
  


  <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\resources\views/home.blade.php ENDPATH**/ ?>