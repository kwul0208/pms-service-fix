

<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="container">
        <div class="row">
            <div class="col-lg-12 col-md-12 mx-auto">
                <div class="post-preview">
                    <a href="javascript:void(0)">
                        <h3 class="post-subtitle">Project Indexd</h3>
                    </a>
                </div>
                <?php echo e(Session::get("employeesId")); ?>

                <?php if(Session::get("employeesId") =='105' ): ?>
                    	
          
                <div class="pull-right">
                    <a href="<?php echo e(url('project/create')); ?>" >
                        <button type="button" class="btn btn-sm btn-primary">Create New</button>
                    </a>
                </div>
                <?php endif; ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Name</th>
                            <th scope="col">Description</th>
                            <th scope="col">PIC</th>
                            <th scope="col">Last Update At</th>
                            <th scope="col">Last Update By</th>
                            <th scope="col">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th scope="row"><?php echo e($key + 1); ?>.</th>
                                <td><?php echo e($project->name); ?></td>
                                <td><?php echo e($project->description); ?></td>
                                <td><?php echo e(@$project->pic->fullname); ?></td>
                                <td><?php echo e($project->last_update); ?></td>
                                <td><?php echo e($project->update_by); ?></td>
                                <td>
                                    <a href="<?php echo e(url('project/'.$project->id)); ?>">
                                        <Button class="btn btn-sm btn-info">Detail</Button>
                                    </a>
                                    <a onclick="return confirm('Are you sure want to delete <?php echo e($project->name); ?>?')" href="<?php echo e(url('project/delete/'.$project->id)); ?>">
                                        <Button class="btn btn-sm btn-danger">Delete</Button>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody> 
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Arsip_Mahrizal\etc\www\projectmanagementsystem\Modules/Project\Resources/views/index.blade.php ENDPATH**/ ?>