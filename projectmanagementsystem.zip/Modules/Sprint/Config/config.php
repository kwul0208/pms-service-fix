<?php

return [
    'name' => 'Sprint'
];
