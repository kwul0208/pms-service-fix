<?php

namespace Modules\Timesheet\Entities;

use Illuminate\Database\Eloquent\Model;

class Timesheet extends Model
{
    protected $fillable = [];
}
