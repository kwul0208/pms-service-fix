<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Team\\Providers\\TeamServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Team\\Providers\\TeamServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);