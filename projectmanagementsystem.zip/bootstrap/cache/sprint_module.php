<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Sprint\\Providers\\SprintServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Sprint\\Providers\\SprintServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);